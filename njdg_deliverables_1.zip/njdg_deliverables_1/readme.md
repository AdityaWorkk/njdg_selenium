1st: First install selenium in your terminal

2nd: Then ensure that the web drive chromedriver is present in you directory in driver/chromedriver format

3rd: Run the python file manual.py