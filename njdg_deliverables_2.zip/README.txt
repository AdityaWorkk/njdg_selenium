first enter the establishment number 1 less than the serial number. Example: if want 3 enter 2
second enter the page number to be extracted. Each page contains 1000 entities so if we want to scrape from 4001 enter page number as 4

Note: If you don't give any inputs it will normally start scraping all the values from the 1st establishment, 1st page
